
// Capturar nome da URL ou localStorage
const params = new URLSearchParams(window.location.search);
const nomeURL = params.get("nome") || params.get("utm_name");
let nome = localStorage.getItem("cliente_nome");

if (nomeURL) {
  nome = nomeURL;
  localStorage.setItem("cliente_nome", nomeURL);
}

const saudacao = nome ? `Olá ${nome}, bem-vindo ao ClickObra App!` : "Olá! Seja bem-vindo ao ClickObra App!";
document.getElementById("mensagemAgente").innerText = saudacao;

// Falar por voz
function falar(mensagem) {
  if ('speechSynthesis' in window) {
    const utter = new SpeechSynthesisUtterance(mensagem);
    utter.lang = "pt-BR";
    const voices = window.speechSynthesis.getVoices();
    const vozFeminina = voices.find(voice => voice.name.toLowerCase().includes("feminina") || voice.name.toLowerCase().includes("female"));
    if (vozFeminina) utter.voice = vozFeminina;
    speechSynthesis.speak(utter);
  }
}

try {
  // Solicita permissão de voz e fala
  falar(saudacao);
} catch (e) {
  console.log("Voz não permitida, usando apenas texto.");
}
