
const nome = new URLSearchParams(window.location.search).get("nome") || "cliente";
const resposta = document.getElementById("resposta");

function responderCliente() {
  const texto = `Olá, ${nome}! Estou aqui para te ajudar. Pode me dizer o que está buscando?`;
  resposta.innerText = texto;
  const fala = new SpeechSynthesisUtterance(texto);
  fala.lang = "pt-BR";
  speechSynthesis.speak(fala);
}

// Produtos simulados
const produtos = [
  { nome: "Cimento CP-II", preco: "R$ 35,00" },
  { nome: "Areia Média", preco: "R$ 120,00/m³" },
  { nome: "Tijolo Baiano", preco: "R$ 1,20" },
];

const vitrine = document.getElementById("produtos");
produtos.forEach(prod => {
  const div = document.createElement("div");
  div.className = "produto";
  div.innerHTML = `<h3>${prod.nome}</h3><p>${prod.preco}</p>`;
  vitrine.appendChild(div);
});
